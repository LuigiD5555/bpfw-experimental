"""Inspector suggestion packages."""
